<?php
//gets incoming data and puts into a data structure
$result = array(
	"First_Name" => $_POST['patient_p_fname'],
	"Last_Name" => $_POST['patient_p_lname'],
	"Birth_Date" => $_POST['patient_p_bdate']
	"Personal_Address" => $_POST['patient_p_address'],
	"Personal_City" => $_POST['patient_p_city'],
	"Personal_State" => $_POST['patient_p_state'],
	"Personal_Zip_Code" => $_POST['patient_p_zcode']
);
//opens the JSON File
$myfile = fopen("registration.json", "w") or die("Unable to open file!");

fwrite($myfile, json_encode($result, JSON_PRETTY_PRINT));
fclose($myfile);
//retrievs the data
//$result['FirstName']

?>